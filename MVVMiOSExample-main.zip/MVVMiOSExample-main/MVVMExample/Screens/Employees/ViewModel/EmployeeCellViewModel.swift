//
//  EmployeeCellViewModel.swift
//  MVVMExample
//
//  Created by Deep on 06/19/20.
//

import Foundation

struct EmployeeCellViewModel {
    var id: String
    var name: String
    var salary: String
    var age: String
}











